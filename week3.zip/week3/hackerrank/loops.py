if __name__ == '__main__':
    n = int(input('enter:'))
    for i in range(n):
        print(i ** 2)
    if n < 0:
        print(i ** 2)
  