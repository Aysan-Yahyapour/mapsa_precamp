def print_full_name(first, last):
    if len(first + last) <= 10:
        print(f'Hello {first_name} {last_name}! You just delved into python.')
    # Write your code here

first_name = input('enter:')
last_name = input('enter:')  
print_full_name(first_name, last_name)

  