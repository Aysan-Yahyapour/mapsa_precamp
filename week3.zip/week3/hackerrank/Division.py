from __future__ import division

if __name__ == '__main__':
    a = int(input('enter:'))
    b = int(input('enter:'))
    print(a // b)
    print(a / b)
    
