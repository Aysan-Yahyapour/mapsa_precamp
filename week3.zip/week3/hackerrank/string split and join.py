def split_and_join(line):

    splitedText = line.split()
    print("-".join(splitedText))

split_and_join('this is a string')