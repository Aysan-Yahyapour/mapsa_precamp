if __name__ == '__main__':
    a = int(input('enter'))
    b = int(input('enter'))
    sum_numbers = a + b
    minus_numbers = a - b
    mul_numbers = a * b
    print(sum_numbers)
    print(minus_numbers)
    print(mul_numbers)
