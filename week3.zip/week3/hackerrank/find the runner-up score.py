my_list = [2, 3, 6, 6, 5]
m = list(set(sorted(my_list)))
p = m.pop(-1)
print(max(m))

